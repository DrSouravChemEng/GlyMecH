%This is the Latest File for Machine learning fitrensemble
%Code Developed and copyright by Dr. Sourav Chatterjee
%Max Planck Institute of Colloids and Interfaces
%ORCID ID 0000-0002-5449-9818
%Please USE MATLAB VERSION R2018a for Running this code
%The Exact system configuration is shown below
%Stastistics and Machine Learning Toolbox used is 11.3 (R2018a)
%-----------------------------------------------------------------------------------------------------
%MATLAB Version: 9.4.0.813654 (R2018a)
%MATLAB License Number: 347765
%Operating System: Microsoft Windows 10 Pro Version 10.0 (Build 18363)
%Java Version: Java 1.8.0_144-b01 with Oracle Corporation Java HotSpot(TM) 64-Bit Server VM mixed mode
%-----------------------------------------------------------------------------------------------------
%MATLAB                                                Version 9.4         (R2018a)
%Simulink                                              Version 9.1         (R2018a)
%Computer Vision System Toolbox                        Version 8.1         (R2018a)
%Image Acquisition Toolbox                             Version 5.4         (R2018a)
%Image Processing Toolbox                              Version 10.2        (R2018a)
%Neural Network Toolbox                                Version 11.1        (R2018a)
%Optimization Toolbox                                  Version 8.1         (R2018a)
%Parallel Computing Toolbox                            Version 6.12        (R2018a)
%Statistics and Machine Learning Toolbox               Version 11.3        (R2018a)
%Symbolic Math Toolbox                                 Version 8.1         (R2018a)

clear all
clc
%%%%%%%%%%%%%%%%%%%%%%Loading all the Excel Data here%%%%%%%%%%%%%%%
%Please replace these with your own excel files%%%%%%%%%%%%%%%%%%%%%
Alphatraining268 = readtable('Alpha training 268.xlsx');
NoAlphatraining268 = readtable('No Alpha training 268.xlsx');
Alphavalidation67 = readtable('Alpha validation 67.xlsx');
NoAlphavalidation67 = readtable('No Alpha validation 67.xlsx');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Preparing the Training Set Data
ResponseAlpha = Alphatraining268(:,'a');  
ValidationAlpha = Alphavalidation67(:,'a');
rng(1); % For Reproducibility
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Machine Learning With Random Forest Regression Algorithm
            
            t = templateTree('NumPredictorsToSample','all',...
                    'PredictorSelection','interaction-curvature','Prune','on','Surrogate','all');

            %Modifying the hyperparameters results in the improvement in optimizations

            Mdl = fitrensemble(NoAlphatraining268,ResponseAlpha,'Method','all','Learners',t,'OptimizeHyperparameters','all',...
              'HyperparameterOptimizationOptions',struct('AcquisitionFunctionName',...
              'expected-improvement-plus','MaxObjectiveEvaluations', 50, 'Repartition',true))


yHat = predict(Mdl,Alphavalidation67); %Prediction is done from the model
ValidationAlpha = table2array(ValidationAlpha);

R2 = (corr(ValidationAlpha,yHat))^2;  
X = [0,100];   %Draw the parity line
Y = [0,100];   %Draw the parity line
plot(X,Y,'-')  %Draw the parity line
axis([0 100 0 100]);  %define the limiter in the graph
hold on

plot(ValidationAlpha,yHat,'*','color',[0.1,0.05,0.018]) %Plotting the overall model fit using the parity plot #The 
xlabel('alpha product obtained [%]') %Plot xlabel in the parity plot
ylabel('Predicted alpha product [%]')
title('Parity plot') % Plotting the title in the parity plot 
hold off

R = [ValidationAlpha yHat] % Result vector 
ExtecSheetParity = xlswrite('parity.xlsx',R) %Writes the results vector in an excel sheet 
PredictorNames = Mdl.PredictorNames;
PredictorNames = PredictorNames';
ExcelSheetPredictorNames = xlswrite('PredictorNames.xlsx',PredictorNames) % Two different Excel sheets are created for 
       %For Storing two different values 

%Please note that SVM will not give the predict imp values
PredictIMP = predictorImportance(Mdl); %Predictor importance is calculated here
PredictIMP = PredictIMP'
figure;
bar(PredictIMP); %Displaying the predictor importance chart

ExcekSheetPredictorImportance = xlswrite('PredictorIMP.xlsx',PredictIMP) % Storing the predictor importance in Excel 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
